# --- Imports --- #

import sprites

# --- Background Class --- #

class Background(object):

    Bg = sprites.Background_List
    X = 0
##    rel_X = X
    Y = 0
##    speed = 5
##    dead = False
##    moving_left = False
##    moving_right = False

##    def movement(self, player_dead):
##        
##        self.dead = player_dead
##        self.rel_X = self.X % sprites.Background_Image.get_rect().width
##
##        if not self.dead:
##            if self.moving_left:
##                self.X += self.speed
##            if self.moving_right:
##                self.X -= self.speed
        
    
